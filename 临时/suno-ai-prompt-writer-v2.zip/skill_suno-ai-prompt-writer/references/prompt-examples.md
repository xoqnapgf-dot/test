# 跨流派完整提示词案例库

全部提示词按 V5.5 Custom Mode 实测沉淀，在 V6 上可直接沿用（字符上限与标签语法未变）。**v6 范式提示：** 以下模板为标签式写法，适合快速复用与试错；v6 对 Style 逐字执行，首次定稿建议参考文末「v6 句子式改写对照」与「完整五栏输出示例」升级为短句描述。若个别案例在 V6 上风格漂移，先检查 Variety 是否关闭（Variety 开启会自动改写 Style 原文）、Style Influence 是否还在默认 50%。Style 字段直接复制粘贴。

## Lo-fi & Chill

**Late Night Study**
```
Lo-fi hip-hop, 75 BPM, warm and introspective, dusty vinyl crackle, mellow jazz piano chords, soft boom bap drums, no vocals, midnight desk lamp energy
```

**Acoustic Morning**
```
Acoustic chill, 82 BPM, peaceful and gentle, fingerpicked nylon guitar, soft brush snare, warm upright bass, whispered male vocals, early morning stillness
```

**Smooth Lounge**
```
Jazz lounge instrumental, 88 BPM, sophisticated and relaxed, warm tenor saxophone, Rhodes electric piano, walking upright bass, brushed drums, 1960s late night atmosphere, no vocals
```

## Electronic & Dance

**Deep House**
```
Deep house, 122 BPM, groovy and hypnotic, warm analog synth bass, chopped vocal samples, four-on-the-floor kick, shimmering hi-hats, late night underground
```

**Synthwave**
```
1980s synthwave, 110 BPM, nostalgic and cinematic, lush analog pads, arpeggiated sequences, gated reverb drums, no vocals, retrofuturistic, influenced by Kavinsky
```

**Ambient Electronic**
```
Ambient electronic, 68 BPM, ethereal and expansive, layered synth textures, granular processing, subtle glitch, no vocals, influenced by Tycho and Boards of Canada
```

**Future Bass**
```
Future bass, 150 BPM, euphoric and emotional, heavy synth swell, chopped vocals, supersaws, punchy kick, festival energy
```

**Industrial Techno**
```
Industrial techno, 135 BPM, relentless and cold, distorted kick, mechanical hi-hats, dark synth pads, no vocals, Berlin underground
```

## Hip-Hop & Rap

**Boom Bap**
```
Boom bap hip-hop, 90 BPM, gritty and authentic, chopped soul sample, punchy drums, vinyl texture, storytelling male rap vocals, 1990s New York, Nas influence
```

**Trap**
```
Trap, 140 BPM, dark and confident, heavy 808 bass, sharp hi-hat triplets, atmospheric synth pads, melodic male rap vocals, modern Atlanta
```

**Lo-fi Rap**
```
Lo-fi rap, 80 BPM, introspective and hazy, jazzy piano loop, soft drums with vinyl crackle, relaxed male flow, late night confessional, Mac Miller influence
```

**UK Drill**
```
UK drill, 140 BPM, cold and menacing, sliding 808 bass, sparse melancholic strings, aggressive male flow, London street narrative
```

## Pop & Indie

**Dream Pop**
```
Dream pop, 95 BPM, ethereal and bittersweet, shimmering reverb guitars, soft synth pads, breathy female vocals with layered harmonies, 2010s aesthetic, Beach House influence
```

**Indie Pop**
```
Indie pop, 118 BPM, bright and restless, jangly electric guitars, punchy synth bass, handclaps, catchy female vocals with harmonies, 2020s bedroom pop
```

**Dark Pop**
```
Dark pop, 92 BPM, moody and minimal, pulsing synth bass, close mic breathy female vocals, sparse production, Billie Eilish influence
```

**Power Pop**
```
Power pop, 132 BPM, energetic and anthemic, crunchy guitars, driving drums, melodic bass line, male vocals, arena chorus, Weezer influence
```

## Rock & Metal

**Indie Rock**
```
Indie rock, 2000s garage rock revival, melancholic and restless, overdriven electric guitar riffs, lo-fi recording, raw male vocals, The Strokes influence
```

**Post-Punk**
```
Post-punk, 145 BPM, urgent and angular, driving bass line, sharp guitar stabs, mechanical drums, spoken vocal delivery, 1980s cold wave
```

**Shoegaze**
```
Shoegaze, 90 BPM, dreamy and noisy, wall of distorted guitars, ethereal reverb-drenched female vocals, heavy tremolo, slow build dynamics, My Bloody Valentine influence
```

**Stoner Rock**
```
Stoner rock, 100 BPM, heavy and hypnotic, fuzz bass, slow thick guitar riffs, deep drums, gritty male vocals, desert atmosphere, Kyuss influence
```

## Cinematic & Ambient

**Epic Trailer**
```
Epic cinematic orchestral, 100 BPM, powerful and triumphant, full brass section, soaring strings, thundering timpani, choir, building to massive climax, no vocals, movie trailer energy
```

**Dark Academy**
```
[Hyper-Realistic] [Instrumental] Dark academia ambient, muffled rain against large windows, ticking grandfather clock, crackling fireplace, classical cello drone, melancholic and scholarly, 60 BPM, D Minor, no vocals
```

**Cyberpunk City**
```
Blade Runner aesthetic, dark synthwave ambient, distant flying cars, neon buzz texture, dystopian yet calm, 60 BPM, D Minor, no vocals
```

**Meditation / Sleep**
```
Ambient meditation, 60 BPM, peaceful and transcendent, soft drone pads, Tibetan singing bowls, gentle wind chimes, no vocals, deep relaxation, 432 Hz tuning
```

## R&B & Soul

**Contemporary R&B**
```
Contemporary R&B, 88 BPM, sultry and warm, Rhodes electric piano, soft 808s, brushed hi-hats, silky female vocals, legato phrasing, late night intimate, 2010s
```

**Neo Soul**
```
Neo soul, 78 BPM, warm and unhurried, soft Rhodes electric piano, gentle plucked upright bass, light percussion, airy female vocals, early afternoon coffee shop
```

**Soul Ballad**
```
Soul ballad, 72 BPM, heartfelt and vulnerable, grand piano, warm strings, subtle organ, powerful female vocals with vibrato-rich sustained notes, intimate verses, 1970s influence
```

## Global & World

**Indian Classical Fusion**
```
Raag Bhairavi Hindustani classical, sitar lead, tanpura drone, tabla, 45 BPM vilambit laya, meditative and devotional, no vocals
```

**Bossa Nova**
```
Bossa nova, 128 BPM, warm and sophisticated, nylon string acoustic guitar, soft percussion, gentle upright bass, soft male vocals in Portuguese, 1960s Rio de Janeiro
```

**Flamenco**
```
Flamenco Soleá, slow tempo, Spanish guitar with rasgueado technique, palmas handclaps, cajón percussion, passionate male vocals, duende quality, no reverb
```

## 极端风格参考

**纯音乐锁定（三重保险）**
```
[Style: Instrumental]
[Instrumental]
(All instrumental lyrics here - no sung words)

Exclude: vocals
```

注意：如果是纯音乐，Lyrics 字段放 [Instrumental] 后最好留空或只写这几个标签。放进歌词的文字的会被唱出来。

**超现实声景**
```
Dark ambient, experimental and textural, processed field recordings, granular synthesis, sub-bass drone, distant metallic resonance, no melody, no rhythm, no vocals
```

---

## v6 句子式改写对照（2026-09 社区验证）

同一首歌的两种写法。标签式（上方模板）适合复用；句子式（v6 逐字执行）适合首次定稿与精确控制：

**Dream Pop（对照上方模板）**
```
Dream pop with shimmering reverb-drenched electric guitars, breathy female
vocals singing close to the microphone with layered harmonies, soft synth
pads underneath, gentle 95 BPM pulse, nostalgic and bittersweet, 2010s
dream pop aesthetic
```

**Trap（对照上方模板）**
```
Dark cinematic trap at 140 BPM, booming 808 bass with sharp hi-hat
triplets, atmospheric synth pads underneath, a confident male rapper with
melodic flow, modern Atlanta sound
```

**Lo-fi（对照 Late Night Study）**
```
Lo-fi hip-hop at 75 BPM with dusty vinyl crackle, mellow jazz piano chords
and soft boom bap drums, warm and introspective, instrumental with no
vocals, midnight desk lamp energy
```

**Epic Trailer（对照上方模板）**
```
Epic cinematic orchestral score at 100 BPM, full brass section and soaring
strings over thundering timpani, building to a massive climax with a
choir, no vocals, movie trailer energy
```

**改写规则（标签式 → 句子式）：**
1. 流派放句首点名（第一权重位）
2. 逐个乐器写"在做什么"，不罗列名词
3. 人声写"是谁、怎么唱、什么感觉"
4. BPM/节奏写成短句成分
5. 氛围词收尾
6. 所有"不要 X"挪进 Exclude，绝不写否定词
7. 总长控制在 Style 1000 字符内，核心元素 4-7 个

---

## 完整五栏输出示例（即贴即用终稿形态）

### 示例一：中文流行叙事歌（含多音字与断句处理）

```
【Style of Music】
Mandopop ballad with warm fingerpicked acoustic guitar and soft strings,
an intimate female vocalist singing close to the mic with breathy,
storytelling delivery, 72 BPM, wistful and tender, polished modern
production

【Lyrics】
[Intro | solo guitar, quiet]

[Verse 1 | whispered, close-mic]
夜色漫过窗台  时间慢了下来
那些没说出口的话  都变成了遗憾

[Pre-Chorus | drums enter softly, voice lifts]
如果重来一遍  我会不会勇敢

[Chorus | full voice, gentle belting, strings swell]
我还想再看你一眼
哪怕只剩下侧脸
（oh～ 回不来）
那些年少的誓言
散落在风里面

[Verse 2 | stripped down, guitar only]
后来的每个冬天  都习惯戴上耳机
单曲循环那首歌  假装你还在听

[Chorus | full voice, gentle belting, strings swell]
我还想再看你一眼
哪怕只剩下侧脸
（oh～ 回不来）
那些年少的誓言
散落在风里面

[Outro | fade out, guitar and strings]
[End]

【Exclude Styles】
autotune, heavy autotune effects, rap, electronic drops, distorted guitars

【Creative Sliders 建议】
Weirdness: 40% ｜ Style Influence: Strong ｜ Variety: Off ｜ Max Mode: 关

【推荐模型】
v6（成品定稿要人声质感与结构稳定；快速试听方向可先用 v6-mini）
```

示范要点：① Style 用 v6 句子式；② 每段带演出指示、副歌歌词完全相同鼓励旋律重复；③ 每行 8-12 字并用空格断句、段间空行控制呼吸；④ 多音字已规避（"还"字在该旋律位读 hái 无歧义，若读 huán 需同音字替换）；⑤ 括号只放真想被唱的 ad-libs；⑥ 排除项全部进 Exclude。

### 示例二：纯音乐氛围曲（三重保险示范）

```
【Style of Music】
Ambient cinematic soundscape, soft drone pads with distant piano notes
and subtle tape hiss, slow swells and long reverb tails, 60 BPM, peaceful
and introspective, instrumental with no vocals, late night atmosphere

【Lyrics】
[Instrumental]
[Intro | solo piano, sparse]
[Instrumental Break | drone pads swell slowly]
[Outro | fade out]
[End]

【Exclude Styles】
vocals, singing, choir, lyrics, rap

【Creative Sliders 建议】
Weirdness: 55% ｜ Style Influence: Medium ｜ Variety: Off ｜ Max Mode: 关

【推荐模型】
v6（氛围曲重稳定；长循环背景音乐可在 Style 开头加 [Sustained] [Minimal Variation]）
```

示范要点：纯音乐三重保险齐备（Style 末尾 no vocals + Lyrics [Instrumental] + Exclude vocals）；Lyrics 只放标签不写文字。
