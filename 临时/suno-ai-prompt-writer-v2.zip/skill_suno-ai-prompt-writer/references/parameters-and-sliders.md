# Suno 参数与滑块参考

## Creative Sliders 详解

位于 Suno 网页版 Advanced Options 中，V4.5 起可用；V6 新增 Variety 滑块与 Max Mode 开关。

### Weirdness（怪异度）
| 范围 | 效果 | 适用场景 |
|------|------|---------|
| 0-30% | 非常安全、保守 | 商业音乐、需要可预测结果的场景 |
| 40-60% | 创意且可控（默认 50% 为 "normal"） | 大多数创作场景，推荐起始点 |
| 60-80% | 明显不寻常 | 追求独特声音实验 |
| 80%+ | 真正的古怪、glitchy | 实验音乐、环境声景 |

### Style Influence（风格影响力）
| 设置 | 效果 | 最佳用法 |
|------|------|---------|
| Loose | Suno 自由发挥 | 探索模式，提示词较短（3-4 元素）时 |
| Medium（默认 50%） | 平衡，但 Style 约一半权威被忽略 | 起步基线；输出泛化时先升档再考虑重写提示词 |
| Strong | 严格遵循 Style | 仅用于精简的 5-8 元素 Style；元素过多时高影响力会导致输出碎片化 |

**默认 50% 警示（2026-09 社区验证）：** 默认设置下，精心写的 Style 字段只有约一半权威被采纳——"输出太泛、不像我写的风格"时，**第一个检查这个滑块**，升到 Strong 通常立竿见影。调 Strong 的前提是把 Style 精简到 5-8 个核心元素（v6 句子式则压缩到一句之内只保留核心信息）。

**关键原则：** Style Influence 设为 Strong 时，Style 字段必须精简聚焦。一个塞了 15 个元素的 Style + Strong 影响力 = 输出难以预测。

### Variety（V6 新增，多样性滑块）

| UI 档位 | API 值 (aug_creativity) | 效果 |
|------|------|------|
| Off | 0 | 所有 v6 系列模型默认；片段使用相同风格 |
| Normal | 1 | 片段之间轻微风格变化 |
| High | 2 | 片段之间较大风格变化 |
| Extra | 3 | 片段之间非常大的风格变化 |
| Max | 4 | 片段可能与输入风格显著差异 |

⚠️ **坑 1（改写 Style）：** 开启 Variety 后 Suno 会自动改写 Style 提示词，V6 首发实测改写结果比用户手写的更短更弱。花功夫建提示词库的用户**建议保持 Off**（即 API 默认 0）。

⚠️ **坑 2（调试抗噪，2026-09 社区沉淀）：** 同一模型两次生成的随机差异，有时比刻意的提示词改动还大。测试某个改动是否有效（换标签、换 BPM、加演出指示）时，把 Variety 保持 Off，否则会把随机噪声误判成改动效果——这是"每次只改一个变量"方法的配套前提。

**与 Max Mode 的分工：** Variety 管"片段之间风格散不散"（横向），Max Mode 管"整首歌一致性强不强"（纵向）。想要稳定别开 Variety，想要长曲一致开 Max Mode，两者不是互相替代。

**模型支持差异：** v6 与 v6-wild 支持全部滑块；**v6-mini 仅支持 Variety**，提交 Weirdness/Style Influence/音频权重会被拒绝。

### Max Mode（V6，极致模式开关）

- 每首歌消耗 **2 倍积分**
- 官方定位：**长歌曲跨段落一致性、Cover 与 Voices 的稳定跟随**，不是单纯音质提升
- 使用时机：曲目中途风格漂移、长曲结构发散、Cover 翻唱不稳定时开启
- v6-mini 不支持 Max Mode

## 滑块 × 模型兼容矩阵（v6 家族）

| 能力 | v6 | v6-wild | v6-mini |
|------|----|---------|---------|
| Weirdness | ✅ | ✅ | ❌ 提交被拒 |
| Style Influence | ✅ | ✅ | ❌ 提交被拒 |
| Variety | ✅ | ✅ | ✅（唯一滑块） |
| Max Mode | ✅ | ✅ | ❌ |
| 字符上限（Style/Lyrics/Title/Exclude） | 1000/5000/100/1000 | 同左 | 同左 |

## 具体数值示例速查（新手直接套用）

按「场景 → 推荐组合」直接给数值，避免新手在 0-100% 之间瞎调：

| 场景 | Weirdness | Style Influence | Variety | 推荐模型 | 说明 |
|------|-----------|-----------------|---------|---------|------|
| 商业/客户交付曲（要可预测） | 20-35% | Strong | Off | v6 | 低怪异 + 强锁定，结果最稳定 |
| 首版快速试听（默认起步） | 50% | Medium | Off | v6-mini 或 v6 | 官方默认，先验证方向 |
| 精确复刻某流派（有清晰参考） | 40-50% | Strong | Off | v6 | 关键：Style 精简到 5-8 元素 |
| 探索新风格（没想好方向） | 50-60% | Loose | Normal | v6-wild | 让 Suno 自由发挥，多生成几首挑 |
| 追求独特声音实验 | 65-80% | Medium | High | v6-wild | 明显不寻常，适合实验电子/声景 |
| 环境声景 / 纯氛围（无结构） | 70-85% | Loose | Off | v6 | 配合 `no melody, no rhythm`（进 Exclude） |
| 长曲一致性 / Cover 翻唱 | 40-50% | Strong | Off | v6 + Max Mode | Max Mode 解决跨段落漂移 |
| 极致怪诞 / glitch | 85-100% | Loose | Extra | v6-wild | 结果不可预测，仅限艺术探索 |

**组合速记：**
- **要稳** → Weirdness 低 + Influence Strong + Variety Off
- **要创意** → Weirdness 中高 + Influence Medium
- **要惊喜** → Weirdness 高 + Influence Loose
- **绝不要** → Weirdness 高 + Influence Strong（怪异 + 强锁定 = 输出崩坏）
- **V6 默认** → Variety Off（保护 Style 原文不被自动改写 + 测试抗噪）；只在明确想要片段间风格变化时开启

**逐轮调整策略（针对「生成不理想」的调参顺序）：**
1. 第一轮：Weirdness 50% + Medium + Variety Off（基线）
2. 输出太泛、不像写的风格 → **Style Influence 先升 Strong**（前提：Style 已精简），这是 v6 时代第一排查项
3. 结果太保守 → Weirdness 提到 60-65%，其余不动
4. 结果太怪 / 跑偏 → Weirdness 降到 30-40%，Influence 保持 Strong
5. 结果风格对但细节散 → 保持 Weirdness，从 Medium 精修 Style 描述（v6 句子式）而非先动滑块
6. 单段不满意 → 不再整首重抽，用 V6 分段编辑自然语言改该段
7. 每次只动一个滑块，改完生成 2-3 首对比再决定下一步

## 版本参数差异

### 各版本模型关键差异

| 特性 | V4 及更早 | V4.5 | V5 | V5.5 | V6 |
|------|----------|------|----|------|-----|
| Style 字符上限 | ~200 | ~1,000 | ~1,000 | ~1,000 | 1,000（v6 首发日页面实测确认） |
| Lyrics 字符上限 | ~3,000 | ~5,000 | ~5,000 | ~5,000 | 5,000（实测确认） |
| Exclude 字符上限 | — | ~1,000 | ~1,000 | ~1,000 | 1,000（实测 maxlength） |
| 最大时长 | 4 分钟 | 8 分钟 | 8 分钟 | 8 分钟（可滑块设定） | Duration Custom/Auto |
| Audio 质量 | 基础 | 良好 | 录音室级 | 录音室级 + 个性化 | 全新训练（Warner/BMG/Believe 授权数据 + 内置合规过滤） |
| Vocals | 有 AI 感 | 改善 | 自然人声 | 带 Voices 克隆 | 更强的人声/结构/情绪理解；歌词块内演出指示被执行 |
| Stems | 无 | 2-stem | 12-stem | 12-stem (+ Advanced Split) | 沿用 + 自然语言采样/隔离 |
| Creative Sliders | 无 | 有（2个） | 有 | 有 | **+ Variety + Max Mode** |
| Voices/Custom Models | 无 | 无 | Persona | Voices + Custom Models | 沿用 + Create Custom Model（Beta，100 积分） |
| My Taste | 无 | 无 | 无 | 所有账户 | 沿用（My Taste 开关 + Workspaces） |
| 新创作功能 | — | — | — | — | 分段编辑 / 歌词精修 / Mashup / 采样隔离 / 多模态输入 / Vibe 创作 |
| 平台级新模型 | — | — | — | — | v6 / v6-wild / v6-mini 三模型；Speech beta（2026-10-01，语音+音乐一体） |

### 重要发现：语法兼容，但阅读方式在 v6 升级

字符上限、metatags 词汇、标签处理方式在 V5.5→V6 **未变**（首发日实测确认），官方称 V6 对人声、器乐、结构、情绪、参考的理解**更准确**——因此为 V5/V5.5 编写的提示词在 V6 上可直接沿用、能跑。

**但 v6 的阅读方式变了（2026-09 社区验证），沿用 ≠ 最优：**
1. **字面化阅读**：v6 逐字执行 Style，v5.x 时代的短标签堆效果漂移，短句描述式更优
2. **歌词块内演出指示被执行**：`[Verse 1 | whispered, close-mic]` 这类指示 v6 会真的唱出来，v5 主要只看 Style
3. **否定词反向理解**：Style 里写 "no X" 在 v6 会被理解成"要 X"，否定必须全部进 Exclude

旧提示词迁移建议：能跑就先跑，效果不理想时按上面三条升级写法，而不是整条重写。

## 所有有效结构标签速查

### 段落结构
```
[Intro]        引子（通常纯器乐）
[Verse 1]      第一主歌
[Verse 2]      第二主歌
[Pre-Chorus]   预副歌（积累张力）
[Chorus]       副歌（主钩子）
[Post-Chorus]  副歌后过渡
[Bridge]       桥段（情绪对比）
[Interlude]    间奏（连接段落）
[Outro]        尾声
[End]          干净结束
[Fade Out]     渐弱结束
```

### 器乐标签
```
[Instrumental]         纯器乐段落（整曲）
[Instrumental Break]   纯器乐段落（插段）
[Guitar Solo]          吉他独奏
[Piano Solo]           钢琴独奏
[Synth Solo]           合成器独奏
[Solo]                 通用独奏
[Drop]                 能量释放（电子音乐）
[Breakdown]            简化段落（电子音乐）
[Build]                积蓄能量
```

### 效果与声音标签
```
[Applause]       掌声
[Birds chirping] 鸟鸣
[Vinyl crackle]  黑胶爆音
[Rain sounds]    雨声
[Phone ringing]  电话铃声
[Silence]        静默
[Crescendo]      渐强
[Diminuendo]     渐弱
[Key Change]     转调
```

### 人声标签
```
[Male Vocal] / [Female Vocal]    指定声部
[Choir]                           合唱
[Harmony] / [Harmonized Chorus]   和声
[Rap]                             说唱
[Whisper] / [Whispered]           低语
[Spoken Word]                     念白
[Ad-lib] / [Ad libs]              即兴伴唱
[Belted] / [Belting]              强力演唱
[Falsetto]                        假声（Tier 2，约 60% 遵从）
```

### 段落级配器控制（参数化标签）
```
[Verse: whispered vocals, acoustic guitar only, sparse]
[Chorus: full band, soaring vocals, wide stereo]
[Bridge: stripped down, piano and cello, different energy]
[Outro: fade out, strings only]
```

### 演出指示格式（v6 新验证，竖线写法）

v6 会执行歌词块内的演出指示，两种写法均有效，竖线格式为 v6 社区沉淀：

```
[Intro | solo piano, quiet]
[Verse 1 | whispered, close-mic]
[Pre-Chorus | drums enter, voice lifts]
[Bridge | Female — Whispered, pitch drifting slightly]
```

规则：外文、50 词以内、写"谁在唱/什么乐器进退/能量变化"；堆太多行内标签会被忽略甚至连带忽略后续歌词。

## V5.5+ 专用技巧

以下标签与技巧为 V5.5 社区实测沉淀；V6 未逐一复测，失效时按「Tier 4 假标签」处理原则降级为描述性语言。

### [Hyper-Realistic] 标签
在 Style 字段开头加 `[Hyper-Realistic]` 推高渲染保真度。

### [Sustained] / [Minimal Variation] 标签
适用于长时间循环背景音乐（如 10 小时 YouTube 环境音），防止编曲向流行结构的高潮发展。

### 纯音乐锁定
纯音乐需要**三重保险**才稳定：
1. Custom Mode 开启 Instrumental 开关
2. Style 字段末尾：`instrumental, no vocals`
3. Exclude 字段：`vocals`
4. Lyrics 字段：`[Instrumental]`（整曲）或 `[Instrumental Break]`（段落）

### Voice 激活后的人声参数调整
- 不要加 gender 描述词（和 Voice 冲突）
- 省下的字符加到编曲和制作细节

### Duration 滑块（网页端 V5.5，2026年7月20日新增）
生成前拖动 Duration 滑块设定歌曲目标长度。V6 中演化为 Duration Custom / Auto 选项。

## 积分消耗与订阅层级（V6 时代，2026-09 起）

| 层级 | 价格 | 积分 | 模型 | 下载 | 商业授权 |
|------|------|------|------|------|---------|
| Free | $0 | 50/天 | v6-mini | ❌ 无下载 | 否 |
| Pro | $8/月 | 2,500/月 | v6 + v6-wild | 20 首/月 | 是 |
| Premier | $24/月 | 10,000/月 | v6 + v6-wild | 60 首/月 | 是 |

注：
- V6 上线后旧模型逐步退役（官方 2026-10 确认整体迁移 v6 世代），Free 档仅 v6-mini 且不可下载
- Max Mode 开启时单首积分消耗 ×2；分段编辑/歌词精修按改动幅度计费，比整首重生成省
- Speech（beta，2026-10-01）为平台级新模型（语音+音乐一体生成），走独立入口，不占用上表模型选项
