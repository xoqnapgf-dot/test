# 人声标签 Tier 分级与实操指南

> Tier 遵从率数据基于 V4.5-V5.5 社区大规模实测。V6 官方称人声理解增强，Tier 沿用作起点；V6 下 Tier 3 概率标签的遵从率预计上升（歌词块内演出指示也被执行，人声控制杠杆变多），待社区复测后更新。

## 遵从率分级（基于社区大规模实测）

### Tier 1 — 可靠（~80% 遵从率）
**必须在 Style 字段或歌词中包含。**

| 标签 | 使用方式 |
|------|---------|
| male vocals / female vocals | Style 字段中直接写 |
| [Whispered] / [Spoken Word] / [Rap] | 歌词字段中括号包裹 |
| [Belting] | 歌词字段 |
| raspy, breathy | Style 字段 |
| 否定提示（no autotune） | ⚠️ 注意拆分："no autotune" 写进 **Exclude** 字段（v6 会反向理解 Style 里的否定词），autotune 一词本身放 Exclude 即可 |

### Tier 2 — 五五开（50-80%）
**最好 Style 和歌词双重强化。**

| 标签 | 建议 |
|------|------|
| [Male Vocal]/[Female Vocal] | 歌词顶部放一次 |
| [Build], [Drop], [Instrumental Break] | 放在对应位置 |
| smooth, gritty, silky | Style 字段 |
| age descriptors（young, mature） | Style 字段 |

### Tier 3 — 概率性（30-50%）
**准备生成 4-6 次挑选。**

| 标签 | 说明 |
|------|------|
| 多词描述性标签 | [Ethereal synth build with rising tension] |
| [Soprano], [Alto] | 无 Style 备份时不可靠 |
| androgynous | 遵从率低 |

### Tier 4 — 假标签（0% 遵从）
**Suno 不解析，应立即删除。**

| 假标签 | 替换方案 |
|--------|---------|
| [Reverb: 30%] | wet reverb / cathedral reverb |
| [Bass: 80%] | sub-bass forward / heavy 808s |
| [Compression: Medium] | punchy compressed / raw dynamics |
| [Stereo Width: Wide] | wide stereo mix |
| [BPM: 120] | 放到 Style 字段写 "120 BPM" |
| [Key: C minor] | 放到 Style 字段写 "C minor" |

## 人声三重堆叠写法

一次命中率最高的结构：

```
[音色 + 性别 + 音域], [发声方式], [情绪特质]
```

示例：
```
breathy female vocals, storytelling delivery, slightly melancholic
raspy male vocals, belting chorus, triumphant energy
silky contralto, legato phrasing, late night intimate
```

## v6 句子式人声写法（2026-09 新增杠杆）

v6 字面化阅读下，把三重堆叠升级成一个短句，同时说清"谁在唱、怎么唱、唱什么感觉"：

```
A breathy female vocalist singing close to the microphone, almost
whispered in the verses, opening up with layered harmonies in the chorus
```

```
Raspy male vocals with a storytelling delivery, slightly behind the beat,
cracking with emotion on the final chorus
```

句子式与三重堆叠可叠加使用：Style 用句子式定整体人声形象，歌词内用演出指示管段落差异（见下节）。

## 演出指示控制人声（v6 新杠杆）

v6 会执行歌词块内的演出指示，段落级人声变化不再只靠 Style 全局描述：

```
[Verse 1 | whispered, close-mic]
[Pre-Chorus | voice lifts, breathier]
[Chorus | full voice, belted, layered harmonies]
[Bridge | Female — Whispered, pitch drifting slightly]
```

要点：
- 指示写"怎么唱"（音量、气息、声区、和声层数），比泛写 "emotional" 有效
- 与 Style 的人声描述保持一致（Style 说 breathy female，指示别突然写 male）
- 仍受 Tier 规律约束：指示里用 Tier 1 词汇（whispered, belted, rap）最可靠

## 控制颤音的正确写法

❌ 错误的全局指令：
```
no vibrato
```

✅ 正确的分段落限幅写法：
```
gentle vibrato at phrase endings, medium-speed vibrato only on sustained chorus notes, no vibrato in verses
```

## 修复人声埋没

如果人声被配器淹没，Style 字段加以下任一组合（社区验证约 60% 改善率）：

```
vocal-forward, spacious mix
```

反直觉但有效：加 `lo-fi` 或 `vintage recording`——低频温暖感反而让人声更突出（Lo-Fi 悖论）。

**v6 兜底：** 生成后人声仍埋没时，可对整曲用分段编辑（自然语言："让整首歌的人声更突出、稍微提高人声音量，其余不变"），或导出后用 Suno 的音轨分离调整。

## Voice 激活后的提示词调整

V5.5 Voices 功能激活后（Pro/Premier）：
- Style 字段中的人声性别描述词变得多余
- 省下来的字符预算花在编曲和制作细节上
- 不加 gender 标签——加了会和 Voice 冲突
