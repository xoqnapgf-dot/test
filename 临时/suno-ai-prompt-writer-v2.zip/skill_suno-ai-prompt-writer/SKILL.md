---
name: suno-ai-prompt-writer
description: Suno AI 音乐生成提示词写作助手。基于 Suno V6 模型家族（2026年9月9日发布，含 v6 旗舰 / v6-wild 实验 / v6-mini 免费三模型）与 v6 发布后社区验证的新范式，涵盖三模型选择路由、v6 字面化阅读与句子化 Style 写法（含标签式对照）、Style 五层写作公式、歌词内演出指示格式（v6 会真正执行）、Creative Sliders（Weirdness/Style Influence 默认 50%/Variety）与 Max Mode 参数控制、完整 metatags 结构标签体系、V6 分段编辑/歌词精修/混搭/采样/多模态输入指令写法、Exclude 排除字段规则（v6 否定词反效果）、人声风格设计与 Tier 分级、流派与融合策略、歌词结构量化基准与断句节奏控制、纯音乐模式、Speech 语音+音乐一体生成（2026-10 beta）、以及 34 组跨流派提示词案例。触发后按 Suno Custom Mode 官方格式输出「即贴即用」的高质量提示词（Style/Lyrics/Exclude 三栏 + Sliders 数值建议 + 推荐模型），并附带输出前自检清单（字符数校验、标签语法验证、多音字与断句检查），帮助用户精准锁定流派、情绪、配器、人声与编曲结构。
---

# Suno AI 提示词写作助手

## 概述

Suno 是一个生成式 AI 音乐平台，可根据文本描述创作完整歌曲（旋律、和声、节奏、配器、人声、歌词、编曲和混音）。目前最新模型家族为 **V6**（2026年9月9日发布），由 **v6 / v6-wild / v6-mini** 三个模型组成；旧模型（V4.5+/V5/V5.5）正在退役，官方已确认平台将整体迁移到 v6 世代（2026-10）。v6 旗舰需要 Pro（\$8/月）或 Premier（\$24/月）订阅，v6-mini 对免费用户开放。

Suno 的核心界面是 **Custom Mode**，分三个字段：
- **Style of Music**：流派、情绪、配器、人声、制作质感
- **Lyrics**：歌词 + 结构标签（metatags）+ 段落演出指示
- **Exclude Styles**：排除不需要的元素

本技能的核心价值：把 Suno V6 官方能力与社区验证过的提示词体系（含 v6 发布后一个月的新范式沉淀）沉淀下来，让用户无论描述多口语化，都能产出一段符合 Custom Mode 规范、可稳定控制的音乐生成提示词。

## 核心三铁律（30 秒上手版）

1. **否定进 Exclude，不进 Style**：v6 会反向理解 Style 里的 "no X"（写成 "no male voice" 反而加男声）。所有排除项写进 Exclude Styles（上限 1000 字符）
2. **v6 逐字执行你写的一切**：Style 用短句描述（流派开头→乐器在做什么→人声怎么唱→BPM）；歌词段落带演出指示（`[Verse 1 | whispered, close-mic]`，外文、50 词内）——写什么给什么，所以只写你真想要的
3. **输出泛化先查滑块再改提示词**：Style Influence 默认只有 50%（一半 Style 权威被忽略）；测试改动时 Variety 保持 Off 抗噪

完整五栏终稿示例（中文流行歌 + 纯音乐）见 `references/prompt-examples.md` 文末。

## V6 三模型选择路由

V6 家族包含三个模型，生成前先按需求路由：

| 模型 | 定位 | 订阅要求 | 滑块支持 | 适用场景 |
|------|------|---------|---------|---------|
| **v6** | 旗舰，精准可预测 | Pro / Premier | 全部滑块 + Max Mode | 成品交付、精准控制 |
| **v6-wild** | 实验，出格大胆 | Pro / Premier | 全部滑块 + Max Mode | 灵感探索、意外惊喜（废片率高，首发实测约半数不可用） |
| **v6-mini** | 快速轻量 | 免费可用 | 仅 Variety | 快速试听、试错、免费用户 |

**路由口诀：要成品选 v6，要灵感选 v6-wild，免费或快速试听选 v6-mini。**

字符上限经 v6 首发日页面实测确认沿用 V5.5 口径：**Style 1,000 / Lyrics 5,000 / Title 100 / Exclude Styles 1,000**。API 侧 mv 对应值：v6 = `chirp-hawk`、v6-wild = `chirp-hawk-wild`、v6-mini = `chirp-goose`。

## 触发条件

当用户表达以下任一意图时触发本技能：

- 要写 / 优化 / 生成一条 Suno AI 音乐生成提示词
- 想让 AI 生成一首带人声或纯音乐的歌曲
- 问 Suno Style 字段怎么写、有什么公式/标签/参数
- 需要参考跨流派提示词案例来套用改写
- 需要排查 Suno 生成出现的常见坑（人声不对、结构散乱、混音模糊等）
- 涉及 Suno Custom Mode、Style 字段、metatags、Creative Sliders、Variety、Max Mode、Exclude、纯音乐模式
- 涉及 Suno V6 模型选择（v6 / v6-wild / v6-mini）或分段编辑、歌词精修、Mashup、采样隔离等新功能用法
- 涉及 Suno Speech（语音+音乐一体生成）或 v6 句子化写法、歌词演出指示

## 核心概念：Suno 的输入结构

### 1. Style of Music 字段（上限 1000 字符）

Style 字段定义音乐特征。**v6 对 Style 的阅读比以往任何版本都更字面**——写什么执行什么，靠前的词权重更高。推荐顺序：

```
[流派 + 子流派], [速度/BPM], [情绪/能量], [核心乐器], [人声特质], [制作质感], [年代/参考]
```

**最佳描述词数量：4-7 个核心元素**。少于 4 个 Suno 会填充泛化默认值，多于 7 个描述词之间可能冲突。

#### 五层公式（社区已验证最稳定的结构）

| 层级 | 控制什么 | 示例 |
|------|---------|------|
| 1. 流派 + 子流派 | 整体方向，必须第一个 | indie folk, dream pop |
| 2. 情绪 + 能量 | 情感调性 | wistful, mid-tempo, bittersweet |
| 3. 人声特质 | 演唱方式，不只是男/女 | breathy female vocals, close-mic |
| 4. 配器 + 质感 | 什么乐器和怎么录制 | fingerpicked acoustic, tape hiss |
| 5. 速度 + 技术参数 | BPM、调性、拍号 | 92 BPM, 4/4, A minor |

**完整 Style 示例（职业级）：**
```
Deep house, 122 BPM, groovy and hypnotic, warm analog synth bass, chopped vocal samples, four-on-the-floor kick, shimmering hi-hats, late night underground
```

#### V6 提示词范式：字面化阅读与句子化写法（2026-09 社区验证）

社区对 251 条旧提示词库的审计显示：为 v5/v5.5 写的短标签堆在 v6 上效果漂移，因为 **v6 逐字执行 Style**。v6 时代**完整短句描述优于纯标签罗列**——先点名流派，然后描述每个乐器和人声在做什么，加 BPM：

```
❌ 标签式（v5.5 时代写法）：
dream pop, breathy female vocals, shimmering guitars, 95 BPM, nostalgic

✅ 句子式（v6 推荐）：
Dream pop with shimmering reverb-drenched guitars, breathy female vocals
singing close to the mic, soft synth pads underneath, 95 BPM, nostalgic
and bittersweet
```

**取舍规则：**
- 精确控制 / 首次定稿 → **句子式**（v6 字面执行，描述什么给什么）
- 模板复用 / 快速试错 → 标签式仍可用（保留五层公式顺序）；配 Style Influence Strong 时必须精简到 5-8 个元素
- 风格可以自然语言描述而非点名（v6 理解力足够，支持非英语描述）；风格词用英文更准，情绪与场景用中文描述也自然，混写没问题
- 不想要的元素一律进 Exclude 字段，**绝不在 Style 里写否定词**（v6 会反向理解，见下文 Exclude 一节）

#### 版本差异（字符上限）

| 字段 | V4 及更早 | V4.5 / V5 / V5.5 / V6 | 最佳实践 |
|------|----------|-----------------|---------|
| Style of Music | ~200 | 1,000（v6 首发日实测确认） | v6：短句描述式，或精简标签式（Strong 档配 5-8 个） |
| Lyrics | ~3,000 | 5,000（实测确认） | 使用结构标签 + 演出指示，约 3000 字符最佳 |
| Title | ~80 | 100（实测确认） | 简短好记 |
| Exclude Styles | — | 1,000（实测 maxlength） | 所有「不要 X」集中在这里 |

> ⚠️ Suno **静默截断**——超过上限不会报错，超出的内容直接被忽略。

### 2. Structure Tags（Metatags）— 结构标签体系

将以下标签放在 Lyrics 字段的方括号中，控制编曲和段落：

#### 必用结构标签
| 标签 | 功能 |
|------|------|
| `[Intro]` | 引子，通常纯器乐 |
| `[Verse 1]` | 主歌，叙事 |
| `[Pre-Chorus]` | 预副歌，积蓄张力 |
| `[Chorus]` | 副歌，主旋律钩子 |
| `[Post-Chorus]` | 副歌后过渡 |
| `[Bridge]` | 桥段，情绪对比 |
| `[Outro]` | 尾声 |
| `[End]` | 干脆结束 |
| `[Fade Out]` | 渐弱结束 |
| `[Instrumental Break]` | 纯器乐段落 |
| `[Solo]` | 独奏段落 |
| `[Drop]` | 电子音乐能量释放 |

#### 人声标签
| 标签 | 功能 |
|------|------|
| `[Male Vocal]` / `[Female Vocal]` | 指定声部 |
| `[Choir]` | 合唱 |
| `[Harmony]` | 和声 |
| `[Rap]` | 说唱 |
| `[Whisper]` / `[Whispered]` | 低语 |
| `[Spoken Word]` | 念白 |
| `[Ad-lib]` | 即兴伴唱 |

#### 动态与制作标签
| 标签 | 功能 |
|------|------|
| `[Fade In]` / `[Fade Out]` | 渐入/渐出 |
| `[Crescendo]` | 渐强 |
| `[Silence]` | 静默停顿 |
| `[Key Change]` | 转调 |
| `[Build]` | 积蓄能量（电子音乐） |
| `[Breakdown]` | 简化段落（电子音乐） |
| `[Tempo: slow]` | 段落级速度控制 |

#### 参数化标签（高级技巧）

在结构标签后加 `: descriptors` 或 `| descriptors` 即可逐段控制配器与演唱：

```
[Verse: whispered vocals, acoustic guitar only, sparse arrangement]
[Chorus: full band, soaring vocals, wide stereo]
[Bridge: stripped down, piano and cello, different energy]
```

#### 演出指示格式（v6 会真正读取，2026-09 社区验证）

v5 时代模型主要只看 Style 字段；**v6 会执行歌词块内的演出指示**——裸段落标题等于浪费控制机会。竖线格式为 v6 社区新验证写法：

```
[Verse 1 | whispered, close-mic]
[Pre-Chorus | drums enter, voice lifts]
[Bridge | Female — Whispered, pitch drifting slightly]
[Intro | solo piano, quiet]
```

要点：指示写人声唱法、配器进退、能量变化；保持外文、50 词以内，过长会被唱出来或被忽略；行内标签不要堆太多，否则 AI 可能跳过提示甚至忽略后续歌词。

#### 完整带标签歌词模板

```
[Intro: sparse, atmospheric]

[Verse 1]
Your first verse lyrics here

[Pre-Chorus]
Building tension...

[Chorus]
Your hook lyrics here

[Verse 2]
Your second verse lyrics

[Chorus]
Your hook lyrics here (same text encourages melodic repetition)

[Bridge: stripped down, different energy]
Contrast section lyrics

[Chorus]
Final hook

[Outro: fade out]
[End]
```

### 3. Exclude Styles 排除字段（上限 1000 字符）

大多数用户留空，但这是**最高性价比的质量杠杆**。把之前生成中反复出现但你不想要的元素写进去：

```
autotune, heavy distortion, live audience, spoken word
```

⚠️ **v6 关键规则：在 Style 字段写否定指令是反效果。** v6 会反向理解 Style 中的否定词——写 "no male voice" 会被解析成"加一个男声"，"no drums" 可能召唤鼓组。所有排除项一律写入 Exclude 字段（v6 首发日实测上限 1,000 字符），逗号分隔。

### 4. Prompt Enhancement Helper

V4.5 推出的 AI 辅助功能，在生成前自动改写 Style 提示词：

**推荐使用场景：**
- 简短模糊的提示词（2-3 个词）→ 打开 Helper 补充细节
- 探索新流派 → 呈现你可能不了解的描述词

**推荐关闭场景：**
- 精确详细的提示词（5 个以上描述词）→ Helper 可能覆盖你的意图
- 重复使用已验证有效的 Style → 需要一致性

> Helper 每次改写结果不同（非确定性），生成后可以查看扩展后的提示词。v6 时代风格描述能力已内置增强，Helper 的必要性进一步下降。

### 5. Creative Sliders 与 Max Mode（V4.5+，V6 扩展）

位于 Advanced Options 中：

| 滑块 | 范围 | 说明 |
|------|------|------|
| Weirdness | 0-100% (默认 50%) | 40-60% 创意且可控；~80%+ 会变得古怪 |
| Style Influence | Loose → Strong（**默认 50% / Medium 档**） | 默认设置下 Style 只有约一半权威被采纳——**输出泛化时第一个检查此滑块**；Strong 仅适用于精简的 5-8 元素 Style，标签过多时高影响力会导致输出碎片化 |
| **Variety（V6 新增）** | Off / Normal / High / Extra / Max | **默认 Off（API 值 0）**。开启后片段间风格变化增大，但会**自动改写 Style 提示词**且改写结果比手写更弱——提示词库用户建议保持 Off；**调试抗噪**：测试提示词改动效果时保持 Off，避免把片段间随机差异误判为改动效果 |
| **Max Mode（V6 新增）** | 开关 | 每首消耗 **2 倍积分**。官方定位：长曲跨段落一致性、Cover 与 Voices 稳定跟随，不是单纯音质提升 |

> V6 的 Variety 对应 API 参数 `aug_creativity`（0=Off / 1=Normal / 2=High / 3=Extra / 4=Max）；**v6-mini 仅支持 Variety**，提交 Weirdness / Style Influence 会被拒绝。

### 6. 个性化层（V5.5 引入，V6 延续）

V5.5（2026年3月）在 V5 音频质量基础上新增 3 个系统，V6 继续沿用：

| 层 | 说明 | 对提示词的影响 |
|----|------|--------------|
| **Voices** | 克隆你自己的声音（Pro/Premier，需验证） | Voice 激活后，Style 中的人声性别描述词（male/female vocals）变得多余 |
| **Custom Models** | 基于你的曲库微调最多 3 个个性化模型 | 流派/情绪标签在自定义模型上行为会不同 |
| **My Taste** | 所有账户自动学习你的偏好 | 使用越久，模糊标签（如 "melancholic indie"）越精准地解析为你的偏好 |

**层堆叠示意图：**
```
Layer 1: My Taste       → 从你的历史形成默认偏好
Layer 2: Custom Model   → 从上传曲库设定制作基线
Layer 3: Voice          → 提供实际人声音色
Layer 4: Prompt         → 引导具体歌曲
```

> **V6 补充（2026-09）：** Create Custom Model 进入 Beta，每次训练消耗 100 积分；新增 Workspaces 多工作区管理；My Taste 增加开关（可在设置中关闭个性化学习）。

## V6 新创作功能与指令写法（2026-09）

V6 发布带来 7 项新创作功能，以自然语言指令驱动，与 Custom Mode 提示词体系互补：

### 1. 分段编辑（Section Editing）

直接用自然语言改单个段落，不整首重生成：

```
把副歌改成福音合唱团演唱，其余部分保持不变
```

要点：只描述要改的段落和改法，明确说「其余部分保持不变」；按改动幅度计费，比整首重生成省积分。

### 2. 歌词精修（Lyrics Precision Editing）

改单词或单行而不重建歌曲：

```
把第二段第 3 行的 "gone" 换成 "home"，旋律和编曲不变
```

要点：适合修错字、换韵脚、微调断句；与本技能的多音字替换法配合——生成后仍可用精修兜底。

### 3. Mashup 混搭

把自己已生成的两首歌混成一首（仅限自己的作品）：

```
Mashup the chorus of "Night Drive" with the verse and drums of "Rainfall"
```

### 4. 采样与乐器隔离（Sampling / Stem Isolation）

用精确时间戳采样歌曲片段或分离乐器：

```
Sample the guitar riff at 0:45 and build a new song around it
```
```
Isolate the vocals from 1:20 to 2:00
```

### 5. 多模态输入（Multimodal Input）

图片、视频、语音均可作为生成输入，配合文字描述补足音乐方向（如风格、情绪、人声要求）。

### 6. Vibe 氛围创作

用氛围描述代替技术参数开场：

```
Make a song that feels like midnight on a rooftop
```

要点：Vibe 适合探索方向；锁定方向后仍回到 Custom Mode 五层公式精确控制。

### 7. 与传统 Custom Mode 的分工

- **首次创作 / 精确控制** → Custom Mode（五层公式 + metatags + Sliders）
- **局部修改** → 分段编辑 / 歌词精修（V6 起替代「整首重抽」）
- **风格探索** → Vibe / v6-wild
- **素材复用** → Mashup / 采样隔离

## 平台动态（2026-10 更新）

- **Speech（beta，2026-10-01）**：业界首个把语音与音乐作为**单一连贯音轨共同生成**的模型，已上线 Android / iOS / Web / Create。适合播客配乐、有声内容、旁白+BGM 一体场景；歌曲音乐创作仍走 v6 家族
- **旧模型退役推进**：官方确认平台整体迁移到 v6 世代；v6 系与 Warner Music、BMG、Believe 授权曲库共建训练，并内置未授权音源与歌词的审查过滤——含明确艺人名「抄袭风格」的请求会被拦，用 "influenced by" 写法规避
- **Suno Studio 10 月更新**：下拍检测精度提升（清唱等节奏不明确素材对齐更稳）、片段按项目速度拉伸（Shift+拖拽）、fade 曲线调节、编辑窗口弹出——偏 DAW 工作流，与提示词写作无直接关系

## 人声控制完整指南

### 人声标签 Tier 分级（社区验证的遵从率）

| 层级 | 遵从率 | 示例 | 含义 |
|------|--------|------|------|
| Tier 1 | 80% | male vocals, female vocals, [Whispered], [Spoken Word], [Rap], [Belting], raspy, breathy, "no autotune" | 可靠，必须包含 |
| Tier 2 | 50-80% | [Male Vocal]/[Female Vocal] 在歌词中，[Build], [Drop], smooth, gritty, age descriptors | 五五开，建议 Style + 歌词双重强化 |
| Tier 3 | 30-50% | 多词描述性标签，androgynous, [Soprano], [Alto] 无 Style 备份 | 概率性，需生成 4-6 次 |
| Tier 4 | 0%（无效） | [Reverb: 30%], [Stereo Width: Wide], [Bass: 80%], 任何数值混音参数 | 假标签，Suno 不解析 |

### 人声描述词分类

**音色：** smoky, airy, bright, nasal, warm, raspy, velvety

**气息感：** breathy, audible air, close-mic intimacy, sigh-like release

**颤音：** no vibrato, gentle vibrato at phrase endings, medium-speed vibrato only on sustained chorus notes

**力度：** soft verse, building pre-chorus, open chorus, subtle swells

**发声方式：** legato, staccato attacks, micro-pauses, late entrances

**人声三重堆叠（最稳定写法）：**
```
[character] + [delivery] + [effects]
```
示例：`breathy female vocals, storytelling delivery, slightly melancholic`

### 常见人声问题修复

| 问题 | 原因 | 修复 |
|------|------|------|
| 人声像机器人 | 过高创造力设置 | 1. 加 "breathy, close-mic" 描述词；2. 降 Weirdness 到 40-50% |
| 人声埋没在混音中 | 乐器描述太多或缺少空间描述 | 加 "vocal-forward" 和 "spacious mix" |
| 音准问题 | 随机生成差异 | 加 "professional trained vocalist" / "on-pitch melodic delivery"，多次生成挑选 |
| 自动修音太重 | 模型默认倾向 | Style 末尾加 "no autotune"，歌词顶部加 [No AutoTune] |

## 流派与风格指南

### 流派格式公式

```
[主流派 + 子流派], [年代/时期], [情绪], [配器 + 质感], [速度], [人声], [参考艺术家]
```

**推荐 4-7 个维度，不要超过 7 个。**

### 12 跨流派提示词模板（社区实测可用，V6 沿用）

**Lo-fi / Chill**
```
Lo-fi hip-hop, 75 BPM, warm and introspective, dusty vinyl crackle, mellow jazz piano chords, soft boom bap drums, no vocals, midnight desk lamp energy
```

**Synthwave / Retrowave**
```
1980s synthwave, 110 BPM, nostalgic and cinematic, lush analog pads, arpeggiated sequences, gated reverb drums, no vocals, retrofuturistic, Kavinsky influence
```

**Deep House**
```
Deep house, 122 BPM, groovy and hypnotic, warm analog synth bass, chopped vocal samples, four-on-the-floor kick, shimmering hi-hats, late night underground
```

**Dream Pop**
```
Dream pop, 95 BPM, ethereal and bittersweet, shimmering reverb guitars, soft synth pads, breathy female vocals with layered harmonies, 2010s aesthetic, Beach House influence
```

**Boom Bap Hip-Hop**
```
Boom bap hip-hop, 90 BPM, gritty and authentic, chopped soul sample, punchy drums, vinyl texture, storytelling male rap vocals, 1990s New York, Nas influence
```

**Trap**
```
Trap, 140 BPM, dark and cinematic, heavy 808 bass, sharp hi-hat rolls, atmospheric synth pads, confident male rap, modern Atlanta
```

**Indie Rock**
```
Indie rock, 2000s garage rock revival, melancholic and restless, overdriven electric guitar riffs, lo-fi recording, raw male vocals, The Strokes influence
```

**Ambient / Cinematic**
```
Cinematic orchestral, 100 BPM, powerful and triumphant, full brass section, soaring strings, thundering timpani, choir, building to massive climax, no vocals, movie trailer energy
```

**R&B**
```
Contemporary R&B, 88 BPM, sultry and warm, Rhodes electric piano, soft 808s, brushed hi-hats, silky female vocals, legato phrasing, late night intimate
```

**Pop Rock**
```
Anthemic pop-rock, 120 BPM, bright and restless, driving electric guitars, punchy bass, big drums, male tenor vocals, wide stereo, arena chorus
```

**Folk / Acoustic**
```
Indie folk rock, mid-tempo, fingerpicked acoustic guitar and mandolin, warm female vocals, lo-fi production, nostalgic and wistful
```

**Ambient / Meditation**
```
Ambient meditation, 60 BPM, peaceful and transcendent, soft drone pads, Tibetan singing bowls, gentle wind chimes, no vocals, deep relaxation
```

### 流派融合技巧

- 保持 2-3 个流派组合，不要超过 3 个
- 用 "meets" 连接：`indie folk meets dream pop`
- 混合文化元素：`Raag Bhairavi Hindustani classical, sitar lead, tanpura drone, tabla, 45 BPM`
- 加年代锚定：`modern` vs `2010s` vs `1980s` 产生完全不同的制作美学

## 纯音乐模式

稳定生成纯音乐需要**三重保险**：

1. **Style 字段末尾**写 `instrumental, no vocals`
2. **Lyrics 字段**放 `[Instrumental]`（整曲）或 `[Instrumental Break]`（段落）
3. **Exclude 字段**填 `vocals`

> 单独只在 Style 写 "no vocals" 不够可靠。

## 实战经验——歌词与提示词注意事项

来源为社区资深用户实操总结，含多版本模型实测数据。

### 歌词情绪表达的核心：段落提示词

写好每段歌词前的提示词（用 `[]` 标注）是控制情绪表达和递进的关键手段。可以借助其他 AI（如 DeepSeek）辅助撰写提示词，但仍需人工调整以达到准确表达。

### 提示词语言与长度规则

- **必须用外文写**，不要中外文混杂——混杂时 AI 有概率直接把提示词唱出来
- **建议 50 词以下**，过长可能导致 AI 略过提示或忽略后面的歌词
- **实测数据**：约 80 词的提示词版本，大概率会被唱出来

### 行内标签的用法与限制

在特定歌词前用 `[]` 标注可控制该句的人声唱法、气息等细节，例如：
```
[Belting] I will always love you
```

但需要注意：
- **不要写太多**行内标签——AI 有概率会忽略提示词，甚至忽略后面的歌词
- **无法精准控制男女声、合唱**：实测表明行内标签无法可靠指定声部，但 Suno 对男女对唱的唱段安排比较合理，"凑合用"级别

### 歌词中标点符号的演唱效果

在歌词中使用 `~`、`!`、空格等符号会对歌唱产生效果，但 AI 有概率忽略。

### 中文多音字处理

| 方案 | 效果 | 注意事项 |
|------|------|---------|
| 同音字替换 | 最佳 | 最稳定可靠 |
| `拼音(字)` 形式 | 体感会增加错误概率 | 可用但需谨慎 |
| 大量拼音替换字 | ❌ V5 能读懂歌词断句，太多拼音影响断句 | 必须手动加空格断句，但断句有时影响演唱效果 |

### 粤语 / 方言控制

在歌词最前面加提示可以降低唱出粤语的概率：
```
[This is a Mandarin song]
```
体感上有效，但 Cover 模式下仍有概率唱粤语。

### 间奏（Interlude）控制

创作带间奏结构的歌曲时，**主动添加单独的间奏标签**很重要——Suno 有时候会偷懒生成特别短的间奏：
```
[Interlude]
```

### Style 提示词的补充建议

除了结构化标签，还可以用**白话详细描绘情绪、故事、人声**，这对准确表达有帮助。但最终 AI 仍需要"抽卡"，只能靠"歌词提示词 + Style 提示词"尽可能固定 AI 对歌曲的理解。

### 关于 Cover 模式的注意事项

Cover 模式会沿用原曲结构，在翻唱中文歌时注意用上述"粤语控制"手段降低方言概率。Cover 模式下推荐留出额外积分进行多轮测试。

## 常见问题排查

| 问题 | 原因 | 解决方案 |
|------|------|---------|
| 生成听起来太普通 | 描述词太少或太泛；或 Style Influence 停在默认 50% | 加 3-5 个具体描述词（子流派、年代、具体乐器、制作质感），并把 Style Influence 调高一档 |
| 人声不符合预期 | 缺少人声描述 | 明确指定性别+音色+演唱方式+情绪特质 |
| 结构混乱 | 缺少 metatags | 用 [Verse], [Chorus], [Bridge], [Outro] 标记结构 |
| 混音模糊 | 多乐器信息或缺少空间描述 | 拆分音轨重平衡，或用 "vocal-forward", "spacious mix" |
| 同一提示词结果差异大 | Suno 内置随机性（有时大于刻意改动） | 同一提示词生成 3-5 次再挑选；测试改动时保持 Variety=Off 抗噪 |
| 风格漂移（小众流派变回流行） | 模型训练数据偏向流行结构 | 加排除标签（进 Exclude）+ 非标准拍号或极端乐器选择 |
| 参数标签无效 | 数值标签不被解析 | 删除 [Reverb: 30%] 等，改用描述性语言 "wet reverb" |
| 否定词召唤了不想要的东西 | v6 反向理解 Style 中的 "no X" | 否定全部挪进 Exclude Styles 字段 |
| 短提示词无效果 | My Taste 未积累 | 新用户需要写 6-8 个标签，My Taste 随使用时间自动优化 |
| 歌词赶拍 / 人声仓促 / 不换气 | 歌词音节密度超出 BPM 承受范围，或缺少换气/断句标记 | 减少每行音节数；加 `,`、`—`、`...` 断句标记；Style 加 "laid-back" "relaxed phrasing" "breathy" |
| 人声连续快速输出、无呼吸感 | 无换气标记 + BPM 过高 + 人声描述缺 breath 词 | 歌词中加 `(breath)` 或 `(rest)`；Style 加 "breathy" "relaxed delivery" "close-mic"；降低 BPM 5-10 |
| 节奏断层 / 段落切换生硬 | 结构标签缺失或过渡段缺少参数化描述 | 加演出指示标签如 `[Chorus: full band, explosive]`；用 `[Pre-Chorus]` 过渡；需控制速度时加 `[Tempo Drop]` / `[Build]` |
| 歌词断句不自然 / 重音错位 | 中文字词多音字；行内音节数不均；缺少断句符号 | 同音字替换多音字；控制每行 8-12 音节；用逗号/破折号/省略号控制断句节奏 |
| 乐器堆砌导致人声发闷 | 超过 5 种乐器描述触发模型降级 | 每段只定义 2-3 种核心乐器；用情绪动词替代乐器罗列 |
| Cover 模式下翻唱粤语/方言 | Cover 模式保留原曲结构，方言朗读习惯影响发音 | 歌词开头加 `[This is a Mandarin song]`；多生成几轮挑选；预留额外积分 |
| 间奏过于短暂 | Suno 倾向自动缩短器乐过渡 | 主动在歌词中加入 `[Interlude]` 标签，配合参数化描述 `[Interlude: 8 bars]` |

## 节奏控制与演唱流畅度优化（高阶专题）

社区实测表明，Suno 的节奏/演唱流畅度问题是多因素耦合的结果，需要系统性地排查。

### 核心根因：歌词音节密度超标

Suno 的演唱引擎以一个稳定的 BPM 格栅（Grid）为基础运行。当歌词的音节密度超过当前 BPM 的承受范围时，人声就会自动"压缩"——表现为赶拍、吞音、不换气。

**自查公式：**
```
平均每行音节数 × 行数 ÷ 段落时长（秒） ≤ 模型可处理密度
```
实操判定：**如果一段歌词你用正常语速默读一遍，发现需要加速才能读完，那 Suno 也会赶拍。** 简化为：**别人能自然读出来的歌词才是好歌词。**

### 6 维控制手段

| 维度 | 手段 | 效果 |
|------|------|------|
| 1. 音节密度 | 精简歌词，每行 8-12 音节，行间留空行 | 最直接、最有效 |
| 2. BPM 对齐 | Style 中精确写 BPM（如 72 而非 "slow"） | 给模型明确速度锚点 |
| 3. 断句符号 | `,` 微停顿、`—` 略长停顿、`...` 渐弱延音、`！` 强调 | 标记自然呼吸点 |
| 4. 人声 breath 词 | Style 字段加 "breathy female vocals, relaxed phrasing" | 引导演唱方式 |
| 5. 结构标签精细化 | `[Verse: sparse, stripped down]` 给段落精确配置 | 每段按不同节奏密度编排 |
| 6. 行内呼吸标记 | 歌词中加 `(breath)` 或 `(rest)` 标签 | 强制呼吸点（遵从不保证） |

### 歌词结构量化基准（社区验证，v6 沿用）

| 规则 | 数值 | 原因 |
|------|------|------|
| 主歌行数 | 4-8 行 | 短主歌旋律更紧；过长会被赶拍 |
| 副歌行数 | 2-4 行 | 短副歌更抓耳、更容易落成钩子 |
| 副歌重复次数 | ≤3 次 | 重复过多显得注水 |
| 最强句位置 | 每段开头 | 首句获得最多旋律权重 |
| 行长节奏 | 长短句交错 | 混合行长制造节奏张力 |

### 歌词间距控制（吸气控制）

在歌词文本中插入空行可以让 Suno 产生呼吸感。每段歌词之间、主歌与副歌之间留空行，是性价比最高的节奏控制方式。

### 音节标注技巧

对需要精确音节数控制的场景，直接在歌词前标注目标：
```
Verse lines: 8-10 syllables each. Chorus lines: 10-12 syllables.
```
对需要拖长音的单词用连字符：`lo-ove`、`sooo-long`。

### 节奏动态标签

| 标签 | 功能 | 最佳使用位置 |
|------|------|-------------|
| `[Build]` | 积蓄能量，节奏/音量逐渐提升 | Pre-Chorus |
| `[Drop]` | 能量释放，全拍进入 | Chorus 开头 |
| `[Tempo Drop]` | 瞬间减速，制造戏剧停顿 | Bridge 或 Outro |
| `[Double Time]` | 节奏骨架翻倍加速（EDM / 嘻哈） | Final Chorus |
| `[Half Time]` | 节奏减半，营造空间 | Bridge |
| `[Break]` / `[Percussion Break]` | 乐器暂停，仅留节奏骨干 | 段落切换 |
| `[Crescendo]` | 渐强 | 高潮前 |
| `[Energy: Low]` / `[Energy: Explosive]` | 指定段落能量级别 | 任何段落 |

### 中文歌词的特殊节奏问题

**多音字是节奏断层的头号元凶。** Suno 对多音字按拼音库硬读，常把"还给我"唱成"huan gei wo"（归还的还），导致咬字错位、节奏卡顿。

**最佳处理方案（优先级从高到低）：**
1. 同音字替换：「还」→「环」，「行」→「航」，「长」→「常」
2. `拼音(字)` 形式（体感增加错误概率，慎用）
3. 大量拼音替换字 → 破坏 V5 断句能力，必须手动空格断句

**歌词符号清理：** 删净所有括号、拼音、emoji、全角空格——这些符号会让 Suno 跳过整行结构标签。

### 测试方法论

1. 口头默读你的歌词——如果自己读得别扭，AI 也会唱得别扭
2. 控制每组歌词 15-30 秒的非人声间隔（[Interlude] / [Instrumental Break]）
3. 单次失败不改写提示词——同一提示词生成 3-5 次再决定
4. 每次只改一个变量（一次只改音节数、或只改 BPM、或只加呼吸标记）；**测试改动时保持 Variety=Off**，否则随机差异会污染对比结论
5. 好结果记下来——建立提示词实验日志

## 标准输出格式（即贴即用）

无论用户需求多口语化，最终都按下面固定五栏输出，让用户**复制粘贴即可直接生成**，无需二次整理或手动微调：

```
【Style of Music】
（直接可粘贴的 Style 字段：v6 首选定稿推荐短句描述式，模板复用可用五层公式精简标签式；否定项一律放 Exclude）

【Lyrics】
（完整歌词 + 结构标签；段落可带演出指示 [Verse 1 | whispered, close-mic]；行间留空行控制呼吸）

【Exclude Styles】
（排除项，留空则写「可留空」）

【Creative Sliders 建议】
Weirdness: xx% ｜ Style Influence: Loose/Medium/Strong ｜ Variety: Off/Normal/High ｜ Max Mode: 关/开

【推荐模型】
v6 / v6-wild / v6-mini（一句话理由，如「成品交付选 v6」「快速试错选 v6-mini」）
```

**输出时同步说明 3 句话以内的使用要点**（如「副歌歌词每次写完全相同文字以鼓励旋律重复」「纯音乐需三重保险」），其余细节留给用户自行查阅，避免一次倾倒过载。

> 原则：**默认给「直接能用的成品」，不要只给「写作方法」**。用户说「我要一首丧丧的雨天民谣」，直接给填好的五栏，而不是让用户按五层公式自己填。

## 完整工作流程

### 从构思到成品的生成循环

```
构思 → 编写 Custom Mode 提示词 → 生成 2 首 → 选择更好的 →
分段编辑 / 歌词精修修细节（V6：用自然语言改单段/单句，不再整首重生成）→
Extend 延续 → Remaster 提升品质 → 导出
```

**要点：** 每首精修曲目通常需要 50-100 积分，为迭代预留积分；V6 的分段编辑按改动幅度计费，比整首重生成省。

### 快速起步模板

用户说 "我要一首 XXX"，直接套用下面流程：

1. 确定流派和子流派（"indie folk" 而非 "folk"）
2. 确定速度和拍号（可给出 BPM）
3. 确定情绪（可用场景描述替代单一情绪词）
4. 确定人声（性别 + 音色 + 发声方式）
5. 确定配器（2-4 种核心乐器 + 质感词）
6. 写歌词或交给 Suno 生成
7. 在歌词中用 [Verse]/[Chorus]/[Bridge] 标出结构，段落加演出指示
8. Exclude 字段排除不想要的元素
9. 决定是否启用 Prompt Enhancement Helper
10. 生成后迭代（第 3-4 次才开始稳定）

## 输出前自检清单（代替工具校验的知识型方案）

本技能为纯知识型，无代码可自动校验，但可用下面这份**结构化检查清单**在每次输出前逐项核对，等效于「字符数校验 + 标签语法验证」工具：

### ① 字符数与长度校验
| 检查项 | 规则 | 不通过时 |
|--------|------|---------|
| Style 字段字符数 | ≤1000（v6 实测上限） | 精简核心元素，删冗余修饰 |
| Lyrics 字段 | ≤5000（约 3000 字符最佳） | 精简歌词或删冗余段落 |
| 段落提示词长度 | ≤50 词（80 词必被唱出） | 压缩为关键词 |
| Exclude 字段 | ≤1000 | 只留高频翻车项 |
| Title | ≤100 | 缩短 |

### ② 标签语法验证
- [ ] 结构标签**全部**用方括号 `[]` 包裹，且拼写正确（`[Verse]` 而非 `[verse]` 或 `(Verse)`）
- [ ] 参数化/演出指示标签格式正确：`[Verse: ...]`（冒号）或 `[Verse 1 | ...]`（竖线），不是 `[Verse whispered]`
- [ ] 数值参数（BPM/调性）放在 **Style 字段**，不放进 Lyrics 方括号（`[BPM: 120]` 是 Tier 4 假标签）
- [ ] Lyrics 内**没有**制作说明（`(鼓在这里爆发)` 会被唱出来）
- [ ] 括号 `()` 只用于 ad-libs 伴唱，且确实想让 AI 唱出来才保留

### ③ 排除项校验
- [ ] 「不要 X」类否定指令**没有**写在 Style 字段（v6 会反向理解成"要 X"，如 "no male voice" → 加男声）
- [ ] 排除项统一写入 **Exclude Styles** 字段，逗号分隔

### ④ 中文歌词专项校验
- [ ] 多音字已处理（「还」→「环」，「行」→「航」，「长」→「常」）
- [ ] 已删净歌词中的拼音、emoji、全角空格、多余括号（否则 Suno 跳过整行标签）
- [ ] 断句符号到位：`,` 微停顿、`—` 略长停顿、`...` 渐弱、`！` 强调
- [ ] 若防粤语：歌词开头已加 `[This is a Mandarin song]`

### ⑤ 纯音乐 / 人声锁定校验
- [ ] 纯音乐 = 三重保险齐备：Style 末尾 `instrumental, no vocals` + Lyrics `[Instrumental]` + Exclude `vocals`
- [ ] 人声 = Style 字段已含「性别 + 音色 + 发声方式」，而非只写 male/female

### ⑥ 自检口诀（快速版）
> **「外文写、标签方括号、否定进 Exclude、数值进 Style、多音字替换、副歌不换字」**

## 版本漂移应对

Suno 迭代快、社区信息更新频繁，本技能标注的版本/字符上限/订阅档位以 **V6（2026-09-09 发布）+ 2026-10 平台动态**为基准。遇到以下情况按对应策略处理，避免沿用过期规则：

| 情况 | 应对 |
|------|------|
| 用户提到更新的模型版本（V7 等） | 承认知识可能滞后，以官方 release-notes 为准，并说明本技能基于 V6 的通用方法论（v6 字面化阅读、描述 > 参数化、metatags 结构、分段编辑）大概率仍适用 |
| 字符上限 / 订阅档位变化 | 提示词**写作方法论不变**（五层公式/句子式、Tier 分级、Exclude 用法），仅需调整字数与档位数据 |
| 某标签失效或新增 | 以「Tier 4 假标签」为判定基准，遇到不生效的参数先删数值改用描述性语言 |
| 无法确认的事实 | 联网搜索 Suno 官方（suno.com/release-notes、help.suno.com）核实后再回答，不凭旧记忆硬答 |

## 参考资源

- Suno 官方：suno.com/blog（V6 版本公告：v6 / v6-wild / v6-mini 三模型，Warner、BMG、Believe 授权合作）
- Suno 发行说明：suno.com/release-notes（含 2026-10 Speech beta 与 Studio 更新）
- Suno 帮助中心 Better Prompts：help.suno.com
- Roo's Newsletter《The Best Suno Prompts After v6》（2026-09-27：251 条提示词库审计 + 24 条 v6 重写，v6 字面化阅读结论来源）
- Digimuziek《Suno v6: Now legal, but you have to relearn prompting》（2026-09-14：Style Influence 默认 50%、Exclude 规则、歌词内指示）
- HookGenius《Suno Character Limits 2026》（v6 首发日页面实测：Style 1000 / Lyrics 5000 / Title 100 / Exclude 1000）与《Suno Prompt Guide 2026》（歌词结构量化基准）
- Suno AI Mastery（LobeHub 技能）
- Blake Crosley Suno 技术指南（2026-08 更新）
- HookGenius Suno Custom Mode 指南（2026-07 更新）
- Jack Righteous Suno 提示工作流（2026-07 更新）
- Ai Unfiltered Suno 提示词库（60+ 跨流派模板实测）
- RaagEngine Suno Prompt Generator（五层结构参考）
- V6 首发实测：weraveyou、beehiiv 实测文档（2026-09-09）
